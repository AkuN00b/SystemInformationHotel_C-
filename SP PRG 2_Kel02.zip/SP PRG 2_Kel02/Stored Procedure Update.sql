-- Membuat sp Update 
-- Hotel 
USE SI_Hotel

--Kamar
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[sp_UpdateKamar]
	@id_kamar		        varchar(10),
	@id_kelas_kamar int,
	@id_jenis_kamar int
AS
BEGIN 
	UPDATE Kamar
	SET id_kelas_kamar = @id_kelas_kamar,
		id_jenis_kamar = @id_jenis_kamar
	WHERE id_kamar = @id_kamar
END

--jenis kamar
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateJenisKamar]
	@id_jenis_kamar		        int,
	@nama_jenis_Kamar		    varchar(50),
	@deskripsi_jenis_kamar		text,
	@harga_jenis_kamar          money
AS
BEGIN 
	UPDATE JenisKamar
	SET nama_jenis_kamar = @nama_jenis_kamar,
		deskripsi_jenis_kamar = @deskripsi_jenis_kamar,
		harga_jenis_kamar = @harga_jenis_kamar
	WHERE id_jenis_kamar = @id_jenis_kamar
END

-- Kelas Kamar 
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateKelasKamar]
	@id_kelas_kamar		        int,
	@nama_kelas_Kamar		    varchar(50),
	@deskripsi_kelas_kamar		text,
	@harga_kelas_kamar          money
AS
BEGIN 
	UPDATE KelasKamar
	SET nama_kelas_kamar = @nama_kelas_kamar,
		deskripsi_kelas_kamar = @deskripsi_kelas_kamar,
		harga_kelas_kamar = @harga_kelas_kamar
	WHERE id_kelas_kamar = @id_kelas_kamar
END

-- Detail Fasilitas Kamar
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[sp_UpdateDetailFasilitasKamar]
	@id_dt_fasilitas int,
	@id_kelas_kamar int,
	@id_fasilitas			varchar(10),
	@qty int,
	@temp int,
	@temp2 int = 0
AS
BEGIN 
	UPDATE DetailFasilitasKamar
	SET id_kelas_kamar = @id_kelas_kamar,
		id_fasilitas = @id_fasilitas,
		qty = @qty
	WHERE id_dt_fasilitas_kamar = @id_dt_fasilitas

	SET @temp2 = @qty
	SET @temp -= @temp2

	UPDATE Fasilitas
	SET qty += @temp
	WHERE id_fasilitas = @id_fasilitas
END

---Menu 
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateMenu]
	@id_menu		        varchar(10),
	@id_jenis_menu			int,
	@nama_menu				varchar(50),
	@harga_menu				money,
	@deskripsi_menu         text,
	@status_menu			int
AS
BEGIN 
	UPDATE Menu
	SET id_jenis_makanan = @id_jenis_menu,
		nama_makanan = @nama_menu,
		harga_makanan = @harga_menu,
		deskripsi_makanan = @deskripsi_menu,
		status_makanan = @status_menu
	WHERE id_menu_makanan = @id_menu
END

--Jenis Menu 
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateJenisMenu]
	@id_jenis_menu		        int,
	@nama_jenis_menu			varchar(50),
	@deskripsi_jenis_menu       text
	
AS
BEGIN 
	UPDATE JenisMenu
	SET nama_jenis_makanan = @nama_jenis_menu,
		deskripsi_jenis_makanan = @deskripsi_jenis_menu
	WHERE id_jenis_makanan = @id_jenis_menu
END

--Ruangan
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[sp_UpdateRuangan]
	@id_ruangan		        varchar(10),
	@deskripsi_ruangan		text,
	@harga_ruangan			money
	
AS
BEGIN 
	UPDATE Ruangan
	SET deskripsi_ruangan = @deskripsi_ruangan,
		harga_ruangan = @harga_ruangan
	WHERE id_ruangan = @id_ruangan
END

--Role 
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateRole]
	@id_role		        int,
	@nama_role				varchar(50)
	
AS
BEGIN 
	UPDATE Role
	SET nama_role= @nama_role
	WHERE id_role= @id_role
END

--- User 
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateUser]
	@id_user		        varchar(10),
	@nama_user				varchar(50),
	@email_user				varchar(50),
	@password			varchar(50),
	@id_role int	
AS
BEGIN 
	UPDATE [User]
	SET nama_user= @nama_user,
		email_user = @email_user,
		password = @password,
		id_role = @id_role
	WHERE id_user= @id_user
END

--- Fasilitas
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateFasilitas]
	@id_fasilitas		        varchar(10),
	@nama_fasilitas				varchar(50),
	@qty						int	
AS
BEGIN 
	UPDATE Fasilitas
	SET nama_fasilitas = @nama_fasilitas,
		qty = @qty
	WHERE id_fasilitas= @id_fasilitas
END

--- Update Status Transaksi Kamar
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateTrsKamar]
	@id_tr_kamar	varchar(10),
	@id_kamar		varchar(10)
AS
BEGIN 
	UPDATE TransaksiKamar
	SET status_transaksi = 2
	WHERE id_tr_kamar= @id_tr_kamar

	UPDATE Kamar
	SET status_kamar = 1
	WHERE id_kamar = @id_kamar
END

--- Update Detail Transaksi Menu
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateDetailTrsMenu]
	@id_tr_dapur		varchar(10),
	@id_menu_makanan	varchar(10),
	@qty				int,
	@total_harga		money,
	@tempHarga			money
AS
BEGIN 
	UPDATE DetailTransaksiPembelian
	SET qty = @qty, total_harga = @total_harga
	WHERE id_tr_dapur = @id_tr_dapur AND id_menu_makanan = @id_menu_makanan

	UPDATE TransaksiPembelian
	SET total_harga += @tempHarga
	WHERE id_tr_dapur = @id_tr_dapur
END

--- Update Pembayaran Menu
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdatePembayaranTransaksiMenu]
	@id_tr_dapur		varchar(10),
	@total_harga		money,
	@status_transaksi	int
AS
BEGIN 
	UPDATE TransaksiPembelian
	SET status_transaksi = @status_transaksi, total_harga = @total_harga
	WHERE id_tr_dapur = @id_tr_dapur
END

--- Update Status Transaksi Ruangan
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateTrsRuangan]
	@id_tr_ruangan	varchar(10),
	@id_ruangan		varchar(10)
AS
BEGIN 
	UPDATE TransaksiRuangan
	SET status_transaksi = 2
	WHERE id_tr_ruangan= @id_tr_ruangan

	UPDATE Ruangan
	SET status_ruangan = 1
	WHERE id_ruangan = @id_ruangan
END